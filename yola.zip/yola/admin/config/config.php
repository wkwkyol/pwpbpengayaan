<?php

define('baseurl','http://localhost/yola/public');