 <!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Portofolio</title>
    <!-- CSS Bootsrap-->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous" />
    <link rel="stylesheet" href="style.css">
    <!-- bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css">
    <!-- My CSS -->
    <link rel="stylesheet" href="<?=baseurl;?>/asset/css/style.css"/>
  </head>
  <body id="home">
    <!--- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-info shadow-sm fixed-top">
      <div class="container">
        <a class="navbar-brand" href="#">Holla</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent" >
          <ul class="navbar-nav ms-auto">
            <li class="nav-item">
              <a class="nav-link active" aria-current="page" href="#home">Home</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#About">About</a>
            </li>
                <li class="nav-item">
                  <a class="nav-link" href="#projects">Project</a></li>
                <li class="nav-item">
                  <a class="nav-link" href="#contact">Contact</a></li>
              </ul>
            </li>
            </li>
          </ul>
        </div>
      </div>
    </nav>
    <!-- Akhir Navbar -->
    <!--jumbotron-->
    <section class="jumbotron text-center">
      <img src="img/Q.jpg" alt="" width="250" height="250" class="rounded-circle img-thumbnail"./>
      <h1 class="display-4">Yola Oktaviana's here</h1>
      <p class="lead">Siswa | SMKN 4 TASIKMALAYA.</p>
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320"><path fill="#ffff" fill-opacity="1" d="M0,256L34.3,266.7C68.6,277,137,299,206,261.3C274.3,224,343,128,411,128C480,128,549,224,617,240C685.7,256,754,192,823,181.3C891.4,171,960,213,1029,213.3C1097.1,213,1166,171,1234,176C1302.9,181,1371,235,1406,261.3L1440,288L1440,320L1405.7,320C1371.4,320,1303,320,1234,320C1165.7,320,1097,320,1029,320C960,320,891,320,823,320C754.3,320,686,320,617,320C548.6,320,480,320,411,320C342.9,320,274,320,206,320C137.1,320,69,320,34,320L0,320Z"></path></svg>
   </section>
  
    <!-- About -->
    <section id="About">
      <div class="row text-center">
        <h2>About</h2>
      </div>
      <div class="row justify-content-center">
          <div class="col-md-4">
            <p>Kunci Kesuksesan itu ada 3. Doa, Usaha dan Orang dalam~</p>
          </div>
          <div class="col-md-4">
            <p>ooooosh1t</p>
          </div>
      </div>
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320"><path fill="#a2d9ff" fill-opacity="1" d="M0,160L34.3,160C68.6,160,137,160,206,181.3C274.3,203,343,245,411,229.3C480,213,549,139,617,144C685.7,149,754,235,823,261.3C891.4,288,960,256,1029,240C1097.1,224,1166,224,1234,202.7C1302.9,181,1371,139,1406,117.3L1440,96L1440,320L1405.7,320C1371.4,320,1303,320,1234,320C1165.7,320,1097,320,1029,320C960,320,891,320,823,320C754.3,320,686,320,617,320C548.6,320,480,320,411,320C342.9,320,274,320,206,320C137.1,320,69,320,34,320L0,320Z"></path></svg>
    </section>
    <!-- Akhir About -->
    <!-- Project -->
    <section id="project">
      <div class="container">
        <div class="row text-center mb-3">
          <div class="col">
            <h2>W E L C O M E</h2>
          </div>
        </div>
        <div class="row justify-content-center">
         <div class="col-md-4 mb-3">
          <div class="card">
          <img src="pic/1.jpg" class="card-img-top" alt="pic1">
          <div class="card-body">
            <p class="card-text">Sebelum sejauh matahari,Kita pernah sedekat nadi~</p>
           </div>
           </div>
          </div>
        <div class="col-md-4 mb-3">
          <div class="card">
          <img src="pic/2.jpg" class="card-img-top" alt="pic2">
          <div class="card-body">
            <p class="card-text">Outside fashion🥵</p>
           </div>
           </div>
          </div>
        <div class="col-md-4 mb-3">
          <div class="card">
          <img src="pic/3.webp" class="card-img-top" alt="pic3">
          <div class="card-body">
            <p class="card-text">School mode👌</p>
           </div>
           </div>
          </div>
        <div class="col-md-4 mb-3">
          <div class="card">
          <img src="pic/4.jpg" class="card-img-top" alt="pic4">
          <div class="card-body">
            <p class="card-text">🍃Reptille Lover Fashion🍃</p>
           </div>
           </div>
          </div>
        <div class="col-md-4 mb-3">
          <div class="card">
          <img src="pic/5.jpg" class="card-img-top" alt="pic5">
          <div class="card-body">
            <p class="card-text">🔥M Y C I R C L E🔥</p>
           </div>
           </div>
          </div>
         </div>
       </div>
      </div>
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320"><path fill="#fff" fill-opacity="1" d="M0,96L26.7,96C53.3,96,107,96,160,85.3C213.3,75,267,53,320,64C373.3,75,427,117,480,122.7C533.3,128,587,96,640,85.3C693.3,75,747,85,800,117.3C853.3,149,907,203,960,197.3C1013.3,192,1067,128,1120,90.7C1173.3,53,1227,43,1280,64C1333.3,85,1387,139,1413,165.3L1440,192L1440,320L1413.3,320C1386.7,320,1333,320,1280,320C1226.7,320,1173,320,1120,320C1066.7,320,1013,320,960,320C906.7,320,853,320,800,320C746.7,320,693,320,640,320C586.7,320,533,320,480,320C426.7,320,373,320,320,320C266.7,320,213,320,160,320C106.7,320,53,320,27,320L0,320Z"></path></svg>
    </section>
    <!-- Akhir Project -->
    <!-- Contact -->
    <section id="contact">
      <div class="container">
        <div class="row text-center mb-3">
          <div class="col">
            <h2>Contact Me</h2>
          </div>
        </div>
        <div class="row justify-content-center">
          <div class="col-md-6">
            <form>
              <div class="mb-3">
                <label for="name" class="form-label">Nama Lengkap</label>
                <input type="text" class="form-control" id="name" aria-describedby="name">
                </div>
                <div class="mb-3">
                  <label for="email" class="form-label">Email</label>
                  <input type="text" class="form-control" id="email" aria-describedby="email">
                </div>
                <div class="mb-3">
                  <label for="pesan" class="form-label">Pesan</label>
                  <textarea class="form-control" id="pesan" rows="3"></textarea>
                </div>
                
             <button type="submit" class="btn btn-primary">Kirim</button>
           </form>
          </div>
        </div>
      </div>
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320"><path fill="#a2d9ff" fill-opacity="1" d="M0,192L26.7,213.3C53.3,235,107,277,160,277.3C213.3,277,267,235,320,192C373.3,149,427,107,480,112C533.3,117,587,171,640,208C693.3,245,747,267,800,261.3C853.3,256,907,224,960,181.3C1013.3,139,1067,85,1120,96C1173.3,107,1227,181,1280,186.7C1333.3,192,1387,128,1413,96L1440,64L1440,320L1413.3,320C1386.7,320,1333,320,1280,320C1226.7,320,1173,320,1120,320C1066.7,320,1013,320,960,320C906.7,320,853,320,800,320C746.7,320,693,320,640,320C586.7,320,533,320,480,320C426.7,320,373,320,320,320C266.7,320,213,320,160,320C106.7,320,53,320,27,320L0,320Z"></path></svg>
    </section>
    <!-- Akhir Contact -->
    
    <!-- Footer -->
    <footer class="text-white text-center pb-4">
      <p>Created by <a href="https:/www.instagram.com/yola_oktaa"class="text-white fw-bold">yola_oktaa</a></p>
    </footer>
    <!-- Akhir Footer -->
    <!-- JavaScript-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
  </body>
</html>