<?php
//menghubungkan ke file init.php yang ada di folder admin
require_once '../admin/init.php';

$app = new App;